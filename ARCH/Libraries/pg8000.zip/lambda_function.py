import pg8000.native
import json

def lambda_handler(event, context):
    
    # Building the database connection

    connection = pg8000.native.Connection(
        host="clinic.chmlmnyewbda.us-east-1.rds.amazonaws.com", 
        port="5432", 
        user="postgres", 
        password="postgres", 
        database="Consultas"
    )
    
    # Executing SQL queries
    # lista: [['a', 'a', 10, 'a', 'a']]
    valores = connection.run("SELECT * FROM Consultas")

    # Closing the cursor
    connection.close()
    
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps(valores)
    }

